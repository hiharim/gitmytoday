package com.example.mytoday;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;


/**
 메인액티비티
 1. 리스트뷰 추가,수정,삭제
 2. 카메라,사진 권한허용
 3. 카메라,사진 업로드
 4. 일기 작성
 5. 달력,통계,설정,검색버튼
 6. 지도api
 7. 기분설정 (1~7)
 8. 날짜,시간 스피너 글쓰는날짜 현재시각보여주기
 */

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Toolbar를 액티비티의 앱바(App Bar)로 지정
        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        //Toolbar에 대한 참조 획득하기
        ActionBar ab=getSupportActionBar();



    }//onCreate



    public boolean onOptionsItemSelected(MenuItem item){

        switch(item.getItemId()){

            case R.id.menu_setting:
                Toast.makeText(this, "설정버튼을 눌렀습니다.", Toast.LENGTH_SHORT).show();
                break;
                

            case R.id.menu_search:
                Toast.makeText(this, "검색버튼을 눌렀습니다.", Toast.LENGTH_SHORT).show();
                break;
        }
        return true;
    }

}//class